# Example5.py
# example on OpenCV and filtering

import cv2 
import numpy as np 

# read the image using imread()
# use 0 for gray-scale
img = cv2.imread('lena512gray.png', 0)

print(type(img))
print(img.shape)

kernel = np.ones((9,9))/81
img_blurred = cv2.filter2D(img,-1,kernel)
# -1 is used to get the output same size as the input

# Display the images
cv2.imshow('Original image', img)	
cv2.imshow('Blurred image', img_blurred)

print('Switch to image view. Then press any key to close')


cv2.waitKey(0)                      # 0 means wait indefinitely for a keystroke. When a key is pressed, the program proceeds
cv2.destroyAllWindows()             # Close the image window   
