# Example4.py
# example on OpenCV

import cv2 
import numpy as np 

# read the image using imread()
# 1 means the image is read as a colored image. use 0 for gray-scale
img = cv2.imread('Fruit.jpg', 1)

print(type(img))
print(img.shape)

# convert to gray-scale
img_gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

# Display the images
cv2.imshow('colored image', img)	
cv2.imshow('gray-scale image', img_gray)

print('Switch to image view. Then press any key to close')


cv2.waitKey(0)                      # 0 means wait indefinitely for a keystroke. When a key is pressed, the program proceeds
cv2.destroyAllWindows()             # Close the image window

# Write the gray-scale image to a file
cv2.imwrite('Fruit_grayscale.jpg', img_gray)   
