# Example3.py
# example on using matplotlib for plotting

import numpy as np
import matplotlib.pyplot as plt

# Make some data to plot.
a = b = np.arange(0, 3, .02)
c = np.exp(a)
d = c[::-1]

# Create plots with pre-defined labels.
fig, ax = plt.subplots()	# this line defines the figure and axis objects
ax.plot(a, c, 'k--', label='Data 1', color = 'r')
ax.plot(a, d, 'k:', label='Data 2', color = 'b')
ax.plot(a, c + d, 'k', label='Sum', color = 'k')
# use legend function to add the legend to the plot
ax.legend()
# uncomment the following line to change some properties of the legend
# legend = ax.legend(loc='upper center', shadow=True, fontsize='x-large')

# Display the figure! without this line program runs without displaying any figure.
plt.show()
# Save the figure to the current directory
fig.savefig('Example3.pdf')
# Close the figure to end the program.
