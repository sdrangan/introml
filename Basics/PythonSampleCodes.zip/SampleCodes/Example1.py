# Example1.py
# simple example on NumPy

import numpy as np

# Define a 2-by-2 array in numpy
a = np.array([[1.0, 2.0], [3.0, 4.0]]) 
print(a)

# get the size of the array
size = a.shape
print(size)

# perform transpose 
b = a.transpose()
print(b)

# Calculate trace
trace = np.trace(a)
print(trace)

# Calculate matrix inverse
inv = np.linalg.inv(a)
print(inv)

# matrix multiplication
product = np.dot(inv,a)
print(product)

# elementwise multiplication
elem_prod = np.multiply(inv,a)
print(elem_prod)