# Example2.py
# Simple example on SciPy

import numpy as np
from scipy import linalg

# Create a vector
a = np.arange(0, 2, .1)
print(a)

# Calculate the L2-norm using the linalg library
L2 = linalg.norm(a)
print(L2)
# Calculate the L2-norm using the mathematical formula
L2_formula = np.sqrt(np.sum(a**2))
print(L2_formula)
# Show there is no difference
print(L2 - L2_formula)

# Calculate the L1-norm using the linalg library
L1 = linalg.norm(a,1)
print(L1)
# Calculate the L1-norm using the mathematical formula
L1_formula = np.sum(np.abs(a))
print(L1_formula)
# Show there is no difference
print(L1 - L1_formula)